
#### the .images (folder)
This folder contains images which will be used on the widget section like 
placeholder images.

* .nomedia : This file prevents images from showing up in your Android 
phone's image gallery.




