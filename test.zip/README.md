# peoplePlugin ![Build Status](https://travis-ci.org/BuildFire/peoplePlugin.svg)

BuildFire Plugin to allow App Owners to include Staff/People into their app and provide contact info. this plugin is scalable to allow for large datasets.
